#ifndef REVERSE_H
#define REVERSE_H

#include "LinkedList.h"
#include <string.h>
using namespace std;

LinkedList<string> * reverse(LinkedList<string> * list);
LinkedList<string> * toList(string str);

#endif
